from chalice import Chalice
import boto3
import uuid

ENDPOINT_URL_SEND ='http://host.docker.internal:4566'
ENDPOINT_URL_RECEIVE = "http://host.docker.internal:4566/_aws/sqs/messages"
QUEUE_URL = "http://queue.localhost.localstack.cloud:4566/000000000000"
QUEUE_NAME = 'MinhaFila.fifo'
REGION = 'us-east-1'

sqs_client = boto3.client('sqs', endpoint_url=ENDPOINT_URL_SEND, region_name=REGION)

app = Chalice(app_name='plugin-spot')
app.debug = True

@app.lambda_function()
def send_messege_fifo(event, context):
	message_body = "Hello World"
	deduplication_id = str(uuid.uuid4())
	id = str(uuid.uuid4())
	response = sqs_client.send_message(
		QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
		MessageBody=message_body,
		MessageDeduplicationId=deduplication_id,
		MessageGroupId=id
	)

def send_messege(message_body):
	response = sqs_client.send_message(
		QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
		MessageBody=message_body,
	)

def get_messagens(response):
	return str(response['Messages'])

def get_messagens2(response):
	return str(response['Messages'][0])

def get_Attributes(response):
	attributes = response['Messages'][0]['Attributes']
	return attributes

def get_MessageId(response):
	attributes = response['Messages'][0]['MessageId']
	return attributes

def receive_message():
	sqs = boto3.client('sqs', endpoint_url=ENDPOINT_URL_RECEIVE)
	response = sqs.receive_message(QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}')
	return response

@app.lambda_function()
def test_lambdas(event, context):
	try:
		response = receive_message()
		MessageId = get_messagens(response)
		return MessageId
	except Exception as e:
		return str(e)

@app.lambda_function()
def test_lambdas2(event, context):
	try:
		response = receive_message()
		MessageId = get_messagens2(response)
		return MessageId
	except Exception as e:
		return str(e)

def send_message(event, context):
	return {"message": "Hello world!"}

""" @app.on_sqs_message(queue='MinhaFila.fifo')
def handler(event):
	for record in event:
		app.log.info("RECEIVED MESSAGE FROM SQS")
		app.log.info(record.body) """




"""
{'Messages':[
	{
		'MessageId': 'e188e6ff-ebec-4709-a4e3-2784feed70d6',
		'ReceiptHandle': 'SQS/BACKDOOR/ACCESS',
		'MD5OfBody': 'b10a8db164e0754105b7a99be72e3fe5',
		'Body': 'Hello World',
		'Attributes': {
			'SenderId': '000000000000',
			'SentTimestamp': '1686336017000',
			'MessageGroupId': '6d144e68-2377-40dd-8c15-321d4c7816b7',
			'MessageDeduplicationId': '4c754e4a-e4ef-47b6-b2d7-1303c6322d86',
			'SequenceNumber': '14485516086163800064',
			'ApproximateReceiveCount': '0',
			'ApproximateFirstR eceiveTimestamp': '0'
		}
	},
	{
		'MessageId': '9804356d-0076-4610-b0b8-7e090fb4a4c9',
		'ReceiptHandle': 'SQS/BACKDOOR/ACCESS',
		'MD5OfBody': 'b10a8db164e0754105b7a99be72e3fe5',
		'Body': 'Hello World',
		'Attributes': {
			'SenderId': '000000000000',
			'SentTimestamp': '1686336098139',
			'MessageGroupId': '12bffaff-a56e-4788-86b2-fcaf571eed44',
			'MessageDeduplicationId': 'e5176c0c-5b3f-46f2-9226-2fe20b9e514f',
			'SequenceNumber': '14485516086163800065',
			'ApproximateReceiveCount': '0',
			'ApproximateFirstReceiveTimestamp': '0'
		}
	},
"""
