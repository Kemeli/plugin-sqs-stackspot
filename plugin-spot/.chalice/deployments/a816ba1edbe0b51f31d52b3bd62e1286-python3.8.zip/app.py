from chalice import Chalice
import boto3
import uuid

ENDPOINT_URL_SEND ='http://host.docker.internal:4566'
ENDPOINT_URL_RECEIVE = "http://host.docker.internal:4566/_aws/sqs/messages"
QUEUE_URL = "http://queue.localhost.localstack.cloud:4566/000000000000"
QUEUE_NAME = 'MinhaFila'

app = Chalice(app_name='plugin-spot')
app.debug = True

def send_duplicate_message():
    message_body = "Hello World"
    sqs_client = boto3.client('sqs', endpoint_url=ENDPOINT_URL_SEND)

    # Envia a primeira mensagem para a fila com MessageDeduplicationId1
    deduplication_id_1 = str(uuid.uuid4())
    response = sqs_client.send_message(
        QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
        MessageBody=message_body,
        MessageDeduplicationId=deduplication_id_1
    )

    # Envia a segunda mensagem para a fila com MessageDeduplicationId2
    deduplication_id_2 = str(uuid.uuid4())
    response = sqs_client.send_message(
        QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
        MessageBody=message_body,
        MessageDeduplicationId=deduplication_id_2
    )

@app.lambda_function()
def send_message(event, context):
	send_duplicate_message()
	return {"message": "Hello world!"}

# @app.on_sqs_message(queue='MinhaFila')
# def handler(event):
# 	for record in event:
# 		app.log.info("RECEIVED MESSAGE FROM SQS")
# 		app.log.info(record.body)

