from chalice import Chalice
import boto3
import uuid

ENDPOINT_URL_SEND ='http://host.docker.internal:4566'
ENDPOINT_URL_RECEIVE = "http://host.docker.internal:4566/_aws/sqs/messages"
QUEUE_URL = "http://queue.localhost.localstack.cloud:4566/000000000000"
QUEUE_NAME = 'MinhaFila.fifo'
REGION = 'us-east-1'

sqs_client = boto3.client('sqs', endpoint_url=ENDPOINT_URL_SEND, region_name=REGION)

app = Chalice(app_name='plugin-spot')
app.debug = True

def send_messege_fifo(id, deduplication_id, delay):
	message_body = "Hello World"
	response = sqs_client.send_message(
		QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
		MessageBody=message_body,
		MessageDeduplicationId=deduplication_id,
		MessageGroupId=id,
		DelaySeconds=delay
	)

@app.lambda_function()
def send_messege_configured2(event, context):
	message_body = "Hello World"
	deduplication_id = str(uuid.uuid4())
	id = str(uuid.uuid4())
	response = sqs_client.send_message(
		QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
		MessageBody=message_body,
		MessageDeduplicationId=deduplication_id,
		MessageGroupId=id
	)

@app.lambda_function()
def send_messege_sqs():
	message_body = "Hello World"
	response = sqs_client.send_message(
		QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
		MessageBody=message_body,
	)

# def receive_message(event, context):
#     sqs = boto3.client('sqs', endpoint_url=ENDPOINT_URL_RECEIVE)
#     response = sqs.receive_message(QueueUrl={QUEUE_URL}/{QUEUE_NAME})
#     return str(response)

# def get_message_id(message_data)
#messege_data[]
#
#
def send_message(event, context):
	return {"message": "Hello world!"}

""" @app.on_sqs_message(queue='MinhaFila.fifo')
def handler(event):
	for record in event:
		app.log.info("RECEIVED MESSAGE FROM SQS")
		app.log.info(record.body) """




@app.lambda_function()
def receive_message(event, context):
    sqs = boto3.client('sqs', endpoint_url=ENDPOINT_URL_RECEIVE)
    response = sqs.receive_message(QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}', MaxNumberOfMessages=1)
    # try:
	# 	return str(response['Messages'])
	# except:
	# 	return (str(response))


