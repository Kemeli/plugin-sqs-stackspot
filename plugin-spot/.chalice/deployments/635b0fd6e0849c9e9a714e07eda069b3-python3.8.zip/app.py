from chalice import Chalice
import boto3
import uuid

ENDPOINT_URL_SEND ='http://host.docker.internal:4566'
ENDPOINT_URL_RECEIVE = "http://host.docker.internal:4566/_aws/sqs/messages"
QUEUE_URL = "http://queue.localhost.localstack.cloud:4566/000000000000"
QUEUE_NAME = 'MinhaFila.fifo'
REGION = 'us-east-1'

sqs_client = boto3.client('sqs', endpoint_url=ENDPOINT_URL_SEND, region_name=REGION)

app = Chalice(app_name='plugin-spot')
app.debug = True

def send_messege_configured(id, deduplication_id, delay):
	message_body = "Hello World"
	response = sqs_client.send_message(
		QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
		MessageBody=message_body,
		MessageDeduplicationId=deduplication_id,
		MessageGroupId=id,
		DelaySeconds=delay
	)

def send_messege_sqs():
	message_body = "Hello World"
	response = sqs_client.send_message(
		QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
		MessageBody=message_body,
	)

# def receive_menssage_sqs

@app.lambda_function()
def send_message(event, context):
	return {"message": "Hello world!"}

""" @app.on_sqs_message(queue='MinhaFila.fifo')
def handler(event):
	for record in event:
		app.log.info("RECEIVED MESSAGE FROM SQS")
		app.log.info(record.body) """



from receive_message import receive_message

@app.lambda_function()
def receive(event, context):
	app.log.info(
		"result %s", receive_message(event, context))


