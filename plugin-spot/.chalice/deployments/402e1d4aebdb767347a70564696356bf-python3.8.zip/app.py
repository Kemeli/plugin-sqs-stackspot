from chalice import Chalice
import boto3
import uuid

ENDPOINT_URL_SEND ='http://host.docker.internal:4566'
ENDPOINT_URL_RECEIVE = "http://host.docker.internal:4566/_aws/sqs/messages"
QUEUE_URL = "http://queue.localhost.localstack.cloud:4566/000000000000"
QUEUE_NAME = 'MinhaFila.fifo'
REGION = 'us-east-1'

sqs_client = boto3.client('sqs', endpoint_url=ENDPOINT_URL_SEND, region_name=REGION)

app = Chalice(app_name='plugin-spot')
app.debug = True

def send_messege_configured(id, deduplication_id, delay):
	message_body = "Hello World"
	response = sqs_client.send_message(
		QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
		MessageBody=message_body,
		MessageDeduplicationId=deduplication_id,
		MessageGroupId=id,
		DelaySeconds=delay
	)

@app.lambda_function()
def send_messege_configured2(event, context):
	message_body = "Hello World"
	deduplication_id = str(uuid.uuid4())
	id = str(uuid.uuid4())
	response = sqs_client.send_message(
		QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
		MessageBody=message_body,
		MessageDeduplicationId=deduplication_id,
		MessageGroupId=id
	)

@app.lambda_function()
def send_messege_sqs():
	message_body = "Hello World"
	response = sqs_client.send_message(
		QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
		MessageBody=message_body,
	)

# def receive_message(event, context):
#     sqs = boto3.client('sqs', endpoint_url=ENDPOINT_URL_RECEIVE)
#     response = sqs.receive_message(QueueUrl={QUEUE_URL}/{QUEUE_NAME})
#     return str(response)

# def get_message_id(message_data)
#messege_data[]
#
#
def send_message(event, context):
	return {"message": "Hello world!"}

""" @app.on_sqs_message(queue='MinhaFila.fifo')
def handler(event):
	for record in event:
		app.log.info("RECEIVED MESSAGE FROM SQS")
		app.log.info(record.body) """




@app.lambda_function()
def receive_message(event, context):
    sqs = boto3.client('sqs', endpoint_url=ENDPOINT_URL_RECEIVE)
    response = sqs.receive_message(QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}')
    return str(response)



"""
{'ResponseMetadata':
	{
		'RequestId': 'acca1a03-feca-4d1b-b48f-4b9d96ee99d6',
		'HTTPStatusCode': 200, 'HTTPHeaders': {'content-type': 'text/xml',
		'content-length': '259',
		'connection': 'close',
		'access-control-allow-origin': '*',
		'access-control-allow-methods': 'HEAD,GET,PUT,POST,DELETE,OPTIONS,PATCH',
	'access-control-allow-headers': 'authorization,cache-control,content-length,content-md5,content-type,etag,location,x-amz-acl,x-amz-content-sha256,
x-amz-date,x-amz-request-id,x-amz-security-token,x-amz-tagging,x-amz-target,x-amz-user-agent,x-amz-version-id,x-amzn-requestid,x-localstack-target,am
z-sdk-invocation-id,amz-sdk-request',
 'access-control-expose-headers': 'etag,x-amz-version-id',
 'date': 'Fri, 09 Jun 2023 18:32:55 GMT', 'server': 'h
ypercorn-h11'}, 'RetryAttempts': 0}}
"""
