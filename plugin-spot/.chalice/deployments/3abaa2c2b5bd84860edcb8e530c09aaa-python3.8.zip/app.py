from chalice import Chalice
import boto3
import uuid

ENDPOINT_URL_SEND ='http://host.docker.internal:4566'
ENDPOINT_URL_RECEIVE = "http://host.docker.internal:4566/_aws/sqs/messages"
QUEUE_URL = "http://queue.localhost.localstack.cloud:4566/000000000000"
QUEUE_NAME = 'MinhaFila.fifo'
REGION = 'us-east-1'

sqs_client = boto3.client('sqs', endpoint_url=ENDPOINT_URL_SEND, region_name=REGION)

app = Chalice(app_name='plugin-spot')
app.debug = True

def send_messege_fifo(id, deduplication_id, delay):
	message_body = "Hello World"
	response = sqs_client.send_message(
		QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
		MessageBody=message_body,
		MessageDeduplicationId=deduplication_id,
		MessageGroupId=id,
		DelaySeconds=delay
	)

@app.lambda_function()
def send_messege_configured2(event, context):
	message_body = "Hello World"
	deduplication_id = str(uuid.uuid4())
	id = str(uuid.uuid4())
	response = sqs_client.send_message(
		QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
		MessageBody=message_body,
		MessageDeduplicationId=deduplication_id,
		MessageGroupId=id
	)

@app.lambda_function()
def send_messege_sqs():
	message_body = "Hello World"
	response = sqs_client.send_message(
		QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}',
		MessageBody=message_body,
	)

# def receive_message(event, context):
#     sqs = boto3.client('sqs', endpoint_url=ENDPOINT_URL_RECEIVE)
#     response = sqs.receive_message(QueueUrl={QUEUE_URL}/{QUEUE_NAME})
#     return str(response)

# def get_message_id(message_data)
#messege_data[]
#
#
def send_message(event, context):
	return {"message": "Hello world!"}

""" @app.on_sqs_message(queue='MinhaFila.fifo')
def handler(event):
	for record in event:
		app.log.info("RECEIVED MESSAGE FROM SQS")
		app.log.info(record.body) """




@app.lambda_function()
def receive_message(event, context):
    sqs = boto3.client('sqs', endpoint_url=ENDPOINT_URL_RECEIVE)
    response = sqs.receive_message(QueueUrl=f'{QUEUE_URL}/{QUEUE_NAME}')
    # try:
	# 	return str(response['Messages'])
	# except:
	# 	return (str(response))



"""
"{'Messages': [{'MessageId': 'e188e6ff-ebec-4709-a4e3-2784feed70d6', 'ReceiptHandle': 'SQS/BACKDOOR/ACCESS', 'MD5OfBody': 'b10a8db164e0754105b7a99be72e3fe5',
'Body': 'Hello World', 'Attributes': {'SenderId': '000000000000', 'SentTimestamp': '1686336017000', 'MessageGroupId': '6d144e68-2377-40dd-8c15-321d4c7816b7',
'MessageDeduplicationId': '4c754e4a-e4ef-47b6-b2d7-1303c6322d86', 'SequenceNumber': '14485516086163800064', 'ApproximateReceiveCount': '0', 'ApproximateFirstR
eceiveTimestamp': '0'}}, {'MessageId': '9804356d-0076-4610-b0b8-7e090fb4a4c9', 'ReceiptHandle': 'SQS/BACKDOOR/ACCESS', 'MD5OfBody': 'b10a8db164e0754105b7a99be
72e3fe5', 'Body': 'Hello World', 'Attributes': {'SenderId': '000000000000', 'SentTimestamp': '1686336098139', 'MessageGroupId': '12bffaff-a56e-4788-86b2-fcaf5
71eed44', 'MessageDeduplicationId': 'e5176c0c-5b3f-46f2-9226-2fe20b9e514f', 'SequenceNumber': '14485516086163800065', 'ApproximateReceiveCount': '0', 'Approxi
mateFirstReceiveTimestamp': '0'}}, {'MessageId': '8d986728-843b-4a2c-b274-9e90647f680b', 'ReceiptHandle': 'SQS/BACKDOOR/ACCESS', 'MD5OfBody': 'b10a8db164e0754
105b7a99be72e3fe5', 'Body': 'Hello World', 'Attributes': {'SenderId': '000000000000', 'SentTimestamp': '1686336100170', 'MessageGroupId': '6463fbaf-6291-493a-
bc00-4fe62985a8e4', 'MessageDeduplicationId': 'd6de6767-61bc-43a8-b721-c49018bd7ac5', 'SequenceNumber': '14485516086163800066', 'ApproximateReceiveCount': '0'
, 'ApproximateFirstReceiveTimestamp': '0'}}], 'ResponseMetadata': {'RequestId': '146df030-61a7-486b-a5c3-c76cc0d2cdb2', 'HTTPStatusCode': 200, 'HTTPHeaders':
{'content-type': 'text/xml', 'content-length': '2707', 'connection': 'close', 'access-control-allow-origin': '*', 'access-control-allow-methods': 'HEAD,GET,PU
T,POST,DELETE,OPTIONS,PATCH', 'access-control-allow-headers': 'authorization,cache-control,content-length,content-md5,content-type,etag,location,x-amz-acl,x-a
mz-content-sha256,x-amz-date,x-amz-request-id,x-amz-security-token,x-amz-tagging,x-amz-target,x-amz-user-agent,x-amz-version-id,x-amzn-requestid,x-localstack-
target,amz-sdk-invocation-id,amz-sdk-request', 'access-control-expose-headers': 'etag,x-amz-version-id', 'date': 'Fri, 09 Jun 2023 18:43:45 GMT', 'server': 'h
ypercorn-h11'}, 'RetryAttempts': 0}}"
"""
